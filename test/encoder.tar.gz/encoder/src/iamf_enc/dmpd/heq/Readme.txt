build steps(linux):

1,./build.sh
2,./HeightMixingParameter replace_audio.wav




build steps(windows):

1, build_win32
2, HeightMixingParameter\HeightMixingParameter.sln